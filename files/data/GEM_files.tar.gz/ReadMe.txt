GEM_metadata.tsv -- a tab separated file containing metadata describing genomes.
annotation_features_counts_wide.tsv -- a tab separated file containing COG abundances in genomes; contains 4318 features (fine resolution)
pathway_features_counts_wide.tsv -- a tab separated file containing COG abundances in genomes aggregated into higher level biochemical pathways; contains 71 features (coarse resolution)


